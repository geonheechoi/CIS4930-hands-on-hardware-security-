#include <stdio.h>
#include <string.h>
#include <limits.h>

int main(void)
{
  heapoverflow();
  printf("Stopping here for example sake, but it would keep going to overflow.\n");
  integeroverflow();
  printf("Now performing stack overflow, which will cause a segmentation fault.\n");
  stackoverflow();
  return 0;
}

int heapoverflow(void)
{
  //heap overflow is allocating memory and then never freeing it
  printf("Performing heap overflow now:\n");\
  //for example sake, perform it only 10 times
  int num1 = 0;
  for (int i = 0; i < 99999999; i++)
  {
    printf("Memory allocation without freeing...\n");
    int *heaps=(int*)malloc(sizeof(int));
    num1++;
    if (num1==10)
    {
      break;
    }
    //allocates memory for each int pointer created without free that space
  }
}

int integeroverflow(void)
{
  printf("Integer overflow example:\n");
  int num = INT_MAX;
  printf("Current integer is %d\n", num);
  printf("When you add anything to the int_max integer 'num', it causes overflow.");
  printf("\nAdding 1 to 'num'.\n");
  num = num + 1;
  printf("Our overflowed integer is now %d\n", num);
}

int stackoverflow(void)
{
  //this can be as simple as declaring a local variable too large for the stack to handle
  int array[1000000][1000000];
  printf("%d\n", array);
}

