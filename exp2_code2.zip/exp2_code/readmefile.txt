# Overflow Examples in C - Code: expr1_1

This program, `expr1_1.c`, demonstrates three different types of overflow scenarios in C programming: heap overflow, integer overflow, and stack overflow. The main purpose of this program is to provide a clear understanding of these overflow scenarios, how they happen, and their consequences.

## Getting Started

You need a C compiler to run this program.

### Requirement

- GCC, the GNU Compiler Collection. If you're on a Unix-like system, such as Linux or macOS, you probably already have GCC installed. If you're on Windows, you can install MinGW (which includes GCC) or another C compiler.

### Running the Program

To run the program:

1. Save the file as `expr1_1.c`.
2. Open a terminal or command prompt.
3. Navigate to the directory where you saved the file. For example, if you saved the file to your desktop, you would do something like the following:

    ```bash
    cd ~/Desktop
    ```

4. Compile the program with GCC:

    ```bash
    gcc expr1_1.c -o expr1_1
    ```

5. Run the program:

    ```bash
    ./expr1_1
    ```

### Explaining the Code

The code is divided into four main functions:

- `main()`: This function calls the other three functions and is where program execution begins.
- `heapoverflow()`: This function demonstrates a heap overflow scenario by repeatedly allocating memory without freeing it.
- `integeroverflow()`: This function demonstrates an integer overflow scenario by trying to increase an integer beyond its maximum limit.
- `stackoverflow()`: This function demonstrates a stack overflow scenario by declaring a local variable that is too large for the stack to handle.




